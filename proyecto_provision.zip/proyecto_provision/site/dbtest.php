<?php
$conn = pg_connect("host=192.168.58.11 dbname=appdb user=appuser password=appsecret");
if (!$conn) {
    echo "<p>Error al conectar a PostgreSQL</p>";
    exit;
}

$result = pg_query($conn, "SELECT * FROM ejemplo;");
echo "<h1>Datos desde PostgreSQL</h1><ul>";
while ($row = pg_fetch_assoc($result)) {
    echo "<li>" . $row['id'] . " - " . $row['nombre'] . "</li>";
}
echo "</ul>";

pg_close($conn);
?>
