#!/usr/bin/env bash
set -e
sudo apt-get update -y
sudo apt-get install -y apache2 php libapache2-mod-php php-pgsql
sudo systemctl enable apache2
sudo systemctl restart apache2
echo "<h1>Hola desde la VM web</h1>" | sudo tee /var/www/html/index.html
