#!/usr/bin/env bash
set -e
sudo apt-get update -y
sudo apt-get install -y postgresql postgresql-contrib
sudo systemctl enable postgresql
sudo systemctl start postgresql
